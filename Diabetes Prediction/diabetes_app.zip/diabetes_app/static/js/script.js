const form = document.getElementById('f');
const out = document.getElementById('out');
const goBtn = document.getElementById('go');
const historyCard = document.getElementById('historyCard');
const historyList = document.getElementById('history');
const EMPTY = '<p class="empty">Fill in the form, or pick an example, then select “Check result”.</p>';

const LABELS = {
  Age: 'Age', Pregnancies: 'Pregnancies', BMI: 'BMI', BloodPressure: 'Blood pressure',
  SkinThickness: 'Skin thickness', Glucose: 'Glucose', Insulin: 'Insulin',
  DiabetesPedigreeFunction: 'Pedigree function'
};

const SAMPLES = {
  low:  {Age: 31, Pregnancies: 1, BMI: 26.6, BloodPressure: 66, SkinThickness: 29, Glucose: 85,  Insulin: 0,   DiabetesPedigreeFunction: 0.351},
  high: {Age: 51, Pregnancies: 5, BMI: 25.8, BloodPressure: 72, SkinThickness: 19, Glucose: 166, Insulin: 175, DiabetesPedigreeFunction: 0.587}
};

// Plain reference ranges, shown as a hint only (they do not affect the model)
function rate(name, v) {
  if (name === 'Glucose')
    return v < 140 ? ['Normal', 'ok'] : v < 200 ? ['Elevated', 'mid'] : ['High', 'bad'];
  if (name === 'BloodPressure')
    return v < 80 ? ['Normal', 'ok'] : v < 90 ? ['Elevated', 'mid'] : ['High', 'bad'];
  if (name === 'BMI')
    return v < 18.5 ? ['Underweight', 'mid'] : v < 25 ? ['Healthy', 'ok'] : v < 30 ? ['Overweight', 'mid'] : ['Obese', 'bad'];
  return null;
}

function updateFlag(name) {
  const el = document.querySelector(`[data-flag="${name}"]`);
  if (!el) return;
  const v = parseFloat(form.elements[name].value);
  const r = Number.isNaN(v) || v <= 0 ? null : rate(name, v);
  el.textContent = r ? r[0] : '';
  el.className = 'flag' + (r ? ' ' + r[1] : '');
}
const flagged = ['Glucose', 'BloodPressure', 'BMI'];
flagged.forEach(n => form.elements[n].addEventListener('input', () => updateFlag(n)));

// BMI helper
const height = document.getElementById('height');
const weight = document.getElementById('weight');
function calcBmi() {
  const h = parseFloat(height.value) / 100, w = parseFloat(weight.value);
  if (h > 0 && w > 0) {
    form.elements.BMI.value = (w / (h * h)).toFixed(1);
    updateFlag('BMI');
  }
}
height.addEventListener('input', calcBmi);
weight.addEventListener('input', calcBmi);

// Example buttons
document.querySelectorAll('[data-sample]').forEach(btn => {
  btn.addEventListener('click', () => {
    const s = SAMPLES[btn.dataset.sample];
    Object.entries(s).forEach(([k, v]) => form.elements[k].value = v);
    flagged.forEach(updateFlag);
    out.innerHTML = EMPTY;
  });
});

// Submit
form.addEventListener('submit', async e => {
  e.preventDefault();
  if (!form.checkValidity()) { form.reportValidity(); return; }
  const data = Object.fromEntries(new FormData(form));
  goBtn.disabled = true; goBtn.textContent = 'Checking…';
  try {
    const res = await fetch('/predict', {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Something went wrong.');
    showResult(json.diabetic, data);
    addHistory(json.diabetic, data);
  } catch (err) {
    out.innerHTML = '<div class="error"></div>';
    out.firstChild.textContent = err.message;
  } finally {
    goBtn.disabled = false; goBtn.textContent = 'Check result';
  }
});

function showResult(diabetic, data) {
  const rows = Object.keys(LABELS).map(k => `<tr><td>${LABELS[k]}</td><td>${data[k]}</td></tr>`).join('');
  const tips = diabetic
    ? ['Book a fasting blood sugar or HbA1c test.', 'Cut back on sugary drinks and refined carbs.', 'Aim for 30 minutes of walking most days.']
    : ['Keep a balanced diet and stay active.', 'Get a blood sugar test once a year.', 'Watch your weight and blood pressure.'];
  out.innerHTML = `
    <div class="verdict ${diabetic ? 'pos' : 'neg'}">
      <strong>${diabetic ? 'Likely diabetic' : 'Likely not diabetic'}</strong>
      <p>${diabetic ? 'These values look like patients who had diabetes in the training data.'
                    : 'These values look like patients who did not have diabetes in the training data.'}</p>
    </div>
    <table class="summary">${rows}</table>
    <ul class="tips">${tips.map(t => `<li>${t}</li>`).join('')}</ul>
    <p class="disclaimer">This is a student ML project, not a medical diagnosis.</p>`;
}

// History (kept in memory; clears on page refresh)
const history = [];
function addHistory(diabetic, d) {
  history.unshift({diabetic, d, time: new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})});
  if (history.length > 5) history.pop();
  renderHistory();
}
function renderHistory() {
  historyCard.hidden = history.length === 0;
  historyList.innerHTML = history.map(h => `
    <li>
      <span>Age ${h.d.Age}, glucose ${h.d.Glucose}<small>${h.time}</small></span>
      <span class="flag ${h.diabetic ? 'bad' : 'ok'}">${h.diabetic ? 'Diabetic' : 'Not diabetic'}</span>
    </li>`).join('');
}
document.getElementById('clearHistory').addEventListener('click', () => { history.length = 0; renderHistory(); });

// Clear
document.getElementById('reset').addEventListener('click', () => {
  form.reset(); height.value = ''; weight.value = '';
  flagged.forEach(updateFlag);
  out.innerHTML = EMPTY;
});
