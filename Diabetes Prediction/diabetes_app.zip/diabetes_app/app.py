import joblib
import pandas as pd
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
model = joblib.load("diabetes_model.pkl")

# (field name, min, max) - same order as the training data columns
FIELDS = [
    ("Pregnancies", 0, 20),
    ("Glucose", 1, 300),
    ("BloodPressure", 1, 200),
    ("SkinThickness", 0, 100),
    ("Insulin", 0, 900),
    ("BMI", 5, 70),
    ("DiabetesPedigreeFunction", 0, 3),
    ("Age", 1, 120),
]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True) or {}
    values = []
    for name, lo, hi in FIELDS:
        try:
            v = float(data.get(name))
        except (TypeError, ValueError):
            return jsonify(error=f"{name} must be a number."), 400
        if not lo <= v <= hi:
            return jsonify(error=f"{name} must be between {lo} and {hi}."), 400
        values.append(v)

    row = pd.DataFrame([values], columns=[f[0] for f in FIELDS])
    pred = int(model.predict(row)[0])
    return jsonify(diabetic=bool(pred))


if __name__ == "__main__":
    app.run(debug=True)
